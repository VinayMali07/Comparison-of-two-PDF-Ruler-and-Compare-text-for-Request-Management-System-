<?php

session_start();
include('includes/config.php');
// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

// Upload files and save names to database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $file1Path = $uploadDir . basename($_FILES['file1']['name']);
    $file2Path = $uploadDir . basename($_FILES['file2']['name']);
    move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
    move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);
    
    // Get the next image number
    $result = mysqli_query($mysqli, "SELECT MAX(img_id) as max_id FROM images");
    $next_id = 0;
    if ($result) {
        $row = mysqli_fetch_array($result);
        
        if ($row['max_id'] !== NULL) {
            $next_id = $row['max_id'] + 1;
        } else {
            $next_id = 1; // or a default value
        }
    }
    // Save file names to database
    $img1_name = "img1-" . $next_id;
    $img2_name = "img2-" . $next_id;
    mysqli_query($mysqli, "INSERT INTO images (img1, img2) VALUES ('$img1_name', '$img2_name')");
    
    // Display uploaded files
    echo "<div class='uploaded-files'>";
    echo "<p>Uploaded Files:</p>";
    echo "<ul>";
    echo "<li><a href='" . $file1Path . "'>" . $img1_name . "</a></li>";
    echo "<li><a href='" . $file2Path . "'>" . $img2_name . "</a></li>";
    echo "</ul>";
    echo "</div>";
        }
       
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Art Work Comparison</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        h2, h4, h5 {
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        .results {
            margin-top: 20px;
        }

        .common-text {
            background-color: #f0f0f0;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .highlight {
            color: green;
        }

        .difference {
            color: red;
        }

        .card-body pre {
            white-space: pre-wrap;
        }
        
    </style>
</head>

<body>
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo d-flex align-items-center">
                <span class="d-none d-lg-block">RMS</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>&nbsp;&nbsp;&nbsp;<h3><b>Request Management System</b></h3>
        </div>
        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <!-- <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle"> -->
                        <!-- <span class="d-none d-md-block dropdown-toggle ps-2">Vinay Mali</span> -->
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6>Vinay Mali</h6>
                            <span>Artwork</span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>

    <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="index.html">
      <i class="bi bi-grid"></i>
      <span>Dashboard</span>
    </a>
  </li><!-- End Dashboard Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-menu-button-wide"></i><span>Masters</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
    <li>
            <a href="test.php">
              <i class="bi bi-circle"></i><span>Activity Master</span>
            </a>
          </li>
          <li>
            <a href="ocr.php">
              <i class="bi bi-circle"></i><span>Artwork image and Text</span>
            </a>
          </li>
          <li>
            <a href="aocr.php">
              <i class="bi bi-circle"></i><span>Atrwork image and Text report</span>
            </a>
          </li>
          <li>
            <a href="docr.php">
              <i class="bi bi-circle"></i><span>Artwork PDF Compare</span>
            </a>
          </li>
          <li>
            <a href="gocr.php">
              <i class="bi bi-circle"></i><span>Image Ruler</span>
            </a>
          </li>
      <!-- <li>
        <a href="ticket_activity.php">
          <i class="bi bi-circle"></i><span>Ticket Activity</span>
        </a>
      </li> -->
     


    <!--<li>
        <a href="components-cards.html">
          <i class="bi bi-circle"></i><span>Cards</span>
        </a>
      </li>
      <li>
        <a href="components-carousel.html">
          <i class="bi bi-circle"></i><span>Carousel</span>
        </a>
      </li>
      <li>
        <a href="components-list-group.html">
          <i class="bi bi-circle"></i><span>List group</span>
        </a>
      </li>
      <li>
        <a href="components-modal.html">
          <i class="bi bi-circle"></i><span>Modal</span>
        </a>
      </li>
      <li>
        <a href="components-tabs.html">
          <i class="bi bi-circle"></i><span>Tabs</span>
        </a>
      </li>
      <li>
        <a href="components-pagination.html">
          <i class="bi bi-circle"></i><span>Pagination</span>
        </a>
      </li>
      <li>
        <a href="components-progress.html">
          <i class="bi bi-circle"></i><span>Progress</span>
        </a>
      </li>
      <li>
        <a href="components-spinners.html">
          <i class="bi bi-circle"></i><span>Spinners</span>
        </a>
      </li>
      <li>
        <a href="components-tooltips.html">
          <i class="bi bi-circle"></i><span>Tooltips</span>
        </a>
      </li>-->
    </ul>
  </li><!-- End Components Nav -->
<!--
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-journal-text"></i><span>Forms</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="forms-elements.html">
          <i class="bi bi-circle"></i><span>Form Elements</span>
        </a>
      </li>
      <li>
        <a href="forms-layouts.html">
          <i class="bi bi-circle"></i><span>Form Layouts</span>
        </a>
      </li>
      <li>
        <a href="forms-editors.html">
          <i class="bi bi-circle"></i><span>Form Editors</span>
        </a>
      </li>
      <li>
        <a href="forms-validation.html">
          <i class="bi bi-circle"></i><span>Form Validation</span>
        </a>
      </li>
    </ul>
  </li>  --><!-- End Forms Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-layout-text-window-reverse"></i><span>Tables</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="tables-general.html">
          <i class="bi bi-circle"></i><span>General Tables</span>
        </a>
      </li>
      <li>
        <a href="tables-data.html">
          <i class="bi bi-circle"></i><span>Data Tables</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Tables Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-bar-chart"></i><span>Charts</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="charts-chartjs.html">
          <i class="bi bi-circle"></i><span>Chart.js</span>
        </a>
      </li>
      <li>
        <a href="charts-apexcharts.html">
          <i class="bi bi-circle"></i><span>ApexCharts</span>
        </a>
      </li>
      <li>
        <a href="charts-echarts.html">
          <i class="bi bi-circle"></i><span>ECharts</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Charts Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-gem"></i><span>Icons</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="icons-bootstrap.html">
          <i class="bi bi-circle"></i><span>Bootstrap Icons</span>
        </a>
      </li>
      <li>
        <a href="icons-remix.html">
          <i class="bi bi-circle"></i><span>Remix Icons</span>
        </a>
      </li>
      <li>
        <a href="icons-boxicons.html">
          <i class="bi bi-circle"></i><span>Boxicons</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Icons Nav -->

  <!-- <li class="nav-heading">Pages</li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="user_profile1.php">
      <i class="bi bi-person"></i>
      <span>Profile</span>
    </a> -->
  <!-- </li>End Profile Page Nav -->

  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="users-profile-aka.php">
      <i class="bi bi-person"></i>
      <span>Profile Management</span>
    </a>
  </li> -->

 

 
  

  

</ul>

</aside><!-- End Sidebar-->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Art Work Comparison</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Art Work</a></li>
                    <li class="breadcrumb-item active"></li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <section class="section">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5  class="btn btn-info">Previous Version</h5></br>
                                            <button type="button" class="btn btn-primary"><i class="bi bi-star me-1"></i> <label for="file1">Choose first file (image/pdf/text):</label></button>
                                            <input type="file"  name="file1" id="file1" required>
                                            <div class="uploaded-images">
                                
                                 <ul>
                                      <li><img src="<?php echo $file1Path; ?>" alt="Uploaded Image 1"style="width: 500px; height: 400px;"></li>
                                     
                                   </ul>
                                  </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="btn btn-info">    New Version   </h5> </br>
                                            <button type="button" class="btn btn-primary"><i class="bi bi-star me-1"></i> <label for="file2">Choose second file (image/pdf/text):</label></button>
                                            <input type="file" name="file2" id="file2" required>
                                            <div class="uploaded-images">
                                
                                              <ul>
                                                    
                                                    <li><img src="<?php echo $file2Path; ?>" alt="Uploaded Image 2" style="width: 500px; height: 400px;"></li>
                                                </ul>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-body">
                                    <input type="submit" class="btn btn-primary" value="Upload and Process">
                                </div>
                            </div>
                        </section>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        function extractTextFromFile($filePath) {
                            $output = '';
                            $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
                            $textFilePath = 'uploads/' . basename($filePath) . '.txt'; // Define the text file path
                    
                            if ($fileExtension == 'pdf') {
                                shell_exec("pdftotext \"$filePath\" \"$textFilePath\"");
                                $output = file_get_contents($textFilePath);
                            } elseif (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                                // Use appropriate OCR method for images
                                // For example, if you're using Tesseract OCR:
                                $output = shell_exec("tesseract \"$filePath\" stdout");
                            } else {
                                // For other file types, simply read the content
                                $output = file_get_contents($filePath);
                            }
                    
                            return $output;
                        }
                    
                    
                    
                        // Rest of the code for file comparison...
                    

                        function highlightText($text, $words, $class) {
                          foreach ($words as $word) {
                              $word = preg_quote($word, '/');
                              $text = preg_replace("/\b($word)\b/", "<span class='$class'>$1</span>", $text);
                          }
                          return $text;
                      }
                      

                        function findCommonAndDifferences($text1, $text2) {
                            $words1 = preg_split('/\s+/', $text1);
                            $words2 = preg_split('/\s+/', $text2);
                            $common = array_intersect($words1, $words2);
                            $diff1 = array_diff($words1, $words2);
                            $diff2 = array_diff($words2, $words1);

                            return [
                                'common' => $common,
                                'diff1' => $diff1,
                                'diff2' => $diff2
                            ];
                        }

                        $uploadDir = 'uploads/';
                        
                        if (!is_dir($uploadDir)) {
                            mkdir($uploadDir, 0777, true);
                        }

                        $file1Path = $uploadDir . basename($_FILES['file1']['name']);
                        $file2Path = $uploadDir . basename($_FILES['file2']['name']);

                        move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
                        move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);

                        $ocrText1 = extractTextFromFile($file1Path);
                        $ocrText2 = extractTextFromFile($file2Path);

                        $results = findCommonAndDifferences($ocrText1, $ocrText2);

                        $highlightedText1 = highlightText($ocrText1, $results['common'], 'highlight');
                        $highlightedText1 = highlightText($highlightedText1, $results['diff1'], 'difference');

                        $highlightedText2 = highlightText($ocrText2, $results['common'], 'highlight');
                        $highlightedText2 = highlightText($highlightedText2, $results['diff2'], 'difference');
                        ?>
                      
                        <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                        <?php
                        echo "<div class='results'>";
                        echo "<table>";
                        echo "<tr>
                        <th>First File Content &nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <th>Second File Content:</th>
                        </tr>";
                        ?>

                        </div>
                        </div>
                    </div>
                    <?php
                        echo "<tr>
                        <td><pre>" . $highlightedText1 . "</pre></td>&nbsp;&nbsp;&nbsp;&nbsp;
                        
                        <td><pre>" . $highlightedText2 . "</pre></td>
                        </tr>";
                       
                       
                        echo "<tr>
                        </tr>";
                        echo "</table>";
                        echo "<table>";
                        echo"<tr>
                        <td>Common Text:</td>
                        <td colspan='2'>
                        <div class='common-text'>
                        <pre>" . implode(' ', $results['common']) . 
                        "</pre></div>
                        </td>
                        </tr>";
                        echo "<tr>
                        <td>Different Text in First File:</td>
                        <td><div class='common-text'>
                        <pre class='difference'>" . implode(' ', $results['diff1']) .
                         "</pre>
                         </div>
                         </td>
                         
                         </tr>";
                        echo "<tr>
                        <td>Different Text in Second File:</td>
                        
                        <td>
                        <div class='common-text'><pre class='difference'>" . implode(' ', $results['diff2']) . 
                        "</pre>
                        </div></td>
                        </tr>";
                        echo "</table>";
                        echo "</div>";
                        
                        echo "</table>";
                                            }
                    ?>
                </div>
            </div>
        </section>
    </main>
</body>

</html>
