<?php
session_start();
include('includes/config.php');





if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['edit'])) {
        // Handle edit form submission
        $oid = $_POST['oid'];
        $level = $mysqli->real_escape_string($_POST['level']);
        $parent_oid = $mysqli->real_escape_string($_POST['parent_oid']);
        $description = $mysqli->real_escape_string($_POST['description']);
        
        $stmt = $mysqli->prepare("UPDATE `master_activity` SET `level`=?, `parent_oid`=?, `description`=? WHERE `oid`=?");
        $stmt->bind_param("sssi", $level, $parent_oid, $description, $oid);
        $stmt->execute();
        $stmt->close();
        
        echo '<script>alert("Record updated successfully."); 
        window.location.href="test.php";</script>';
    } elseif (isset($_POST['delete'])) {
        // Handle delete form submission
        $oid = $_POST['oid'];
        
        $stmt = $mysqli->prepare("DELETE FROM `master_activity` WHERE `oid`=?");
        $stmt->bind_param("i", $oid);
        $stmt->execute();
        $stmt->close();
        
        echo '<script>alert("Record deleted successfully."); 
        window.location.href="test.php";</script>';
    }
}

// Fetch all records
$result = $mysqli->query("SELECT * FROM `master_activity`");

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Components </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <script>


  </script>
  
</head>

<body>


  

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="index.html">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Masters</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="test.php">
              <i class="bi bi-circle"></i><span>Activity Master</span>
            </a>
          </li>
          <li>
            <a href="ocr.php">
              <i class="bi bi-circle"></i><span>Artwork image and Text</span>
            </a>
          </li>

          <li>
            <a href="aocr.php">
              <i class="bi bi-circle"></i><span>Atrwork image371
                 and Text report</span>
            </a>
          </li>

          <li>
            <a href="docr.php">
              <i class="bi bi-circle"></i><span>Artwork PDF Compare</span>
            </a>
          </li>
          <li>
            <a href="gocr.php">
              <i class="bi bi-circle"></i><span>Image Ruler</span>
            </a>
          </li>
          <!-- <li>
            <a href="user-mastergroup1.php">
              <i class="bi bi-circle"></i><span>User Group</span>
            </a>
          </li> -->
          </ul>
      </li><!-- End Components Nav -->

    <!-- End Tables Nav -->

      <li class="nav-item">
       
        <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
         
        </ul>
      </li><!-- End Charts Nav -->

     
      <!-- <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.php">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li>End Profile Page Nav -->

      


    
      </li><!-- End Login Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Master Activity</h1>
      
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!--hi use thi-->
<!-- Primary Color Bordered Table -->
<h5 class="card-title">Master Activity</h5>
<table class="table table-bordered border-primary">
  <thead>
    <tr>
      <th>Sno.</th>
      <th> Level</th>
      <th>Parent</th>
      <th>Description</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['oid']; ?></td>
                    <td><?php echo $row['level']; ?></td>
                    <td><?php echo $row['parent_oid']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td>
                        <button class="btn btn-primary" onclick="editRecord(<?php echo $row['oid']; ?>, '<?php echo $row['level']; ?>', '<?php echo $row['parent_oid']; ?>', '<?php echo $row['description']; ?>')">Edit</button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="oid" value="<?php echo $row['oid']; ?>">
                            <button type="submit" name="delete" id="delete" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>                        
                    </tbody>

  
                </table>
<!-- End Primary Color Bordered Table -->
              
        <!-- Edit Modal -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Record</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="oid" id="oid">
                            <div class="mb-3">
                                <label for="level" class="form-label">Level</label>
                                <input type="text" class="form-control" name="level" id="level" required>
                            </div>
                            <div class="mb-3">
                                <label for="parent_oid" class="form-label">Parent</label>
                                <input type="text" class="form-control" name="parent_oid" id="parent_oid" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" name="description" id="description" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="edit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
          


            </div>
          </div>

        </div>
        
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Extra Large Modal -->
              <div class="pagetitle">
                  <h1>Add New Master Activity</h1>
                    </div>

              <button type="button" name="Add_button" id="Add_button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ExtralargeModal1">
                Add New Master Activity
              </button>
              
              <div class="modal fade" id="ExtralargeModal1" tabindex="-1">
                <div class="modal-dialog modal-xl">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Add Master Activity</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                     <form method="POST" action="#">
                    <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Level :</b></label>
                  <div class="col-sm-10">

                  <select class="form-select" aria-label="multiple select example" required name="level" id="level">
                      <option value="">select option</option>
                      <?php 
                    $query ="SELECT * FROM activity_level";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->levels;?>"><?php echo $row->levels;?></option>
                    <?php } ?>
                    </select>
                    <!-- <input type="text" name="level" id="level" class="form-control"> -->                     
                  </div>
                </div>
              

                <div class="row mb-5">
                 <label class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Parent :</b></label>
                  <div class="col-sm-10">
                    <select class="form-select" aria-label="multiple select example" required name="parent_oid" id="parent_oid">
                      <option value="">select option</option>
                      <?php 
                    $query ="SELECT * FROM master_activity";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->parent_oid;?>"><?php echo $row->parent_oid;?></option>
                    <?php } ?>
                    </select>
                  </div>
                </div>


                <div class="row mb-3">
               <label for="inputPassword" class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Description :</b></label>
                  <div class="col-sm-10">
                  <input type="text" name="description" id="description" class="form-control">
                  </div>
                </div>


                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                      <button type="submit"  name="submit"   class="btn btn-primary">Save</button>
                      <!-- <button class="btn btn-success" onclick="saveData()">Add Master</button> -->
                    </div>
                  </div>
                </div>
                    </form>
              </div><!-- End Extra Large Modal-->
              <?php
                //session_start();
                include('includes/config.php');
                //include('includes/checklogin.php');
                //check_login();
             //include('includes/checklogin.php');
//check_login();

                    if(isset($_POST['submit'])){
                        $level = $_POST['level'];
                        $parent_oid = $_POST['parent_oid'];
                        $description = $_POST['description'];
                        //$dob = $_POST['dob'];
                        //$password =$_POST['password'];
                        //$cpassword = $_POST['cpassword'];


                        mysqli_query($mysqli,"INSERT INTO master_activity (level,parent_oid,description) VALUES('$level','$parent_oid','$description')") or die("Error Occured");

                        echo '<script>
                    alert("Activity Master added successful");
                    window.location="test.php";
                    </script>';
 }
?>

                


  <!--button end-->
            </div>
          </div>

        </div>
      </div>
    </section>


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
   
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        function editRecord(oid, level, parent_oid, description) {
            document.getElementById('oid').value = oid;
            document.getElementById('level').value = level;
            document.getElementById('parent_oid').value = parent_oid;
            document.getElementById('description').value = description;
            var editModal = new bootstrap.Modal(document.getElementById('editModal'));
            editModal.show();
        }
    </script>
  
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>


<?php
$mysqli->close();
?>
