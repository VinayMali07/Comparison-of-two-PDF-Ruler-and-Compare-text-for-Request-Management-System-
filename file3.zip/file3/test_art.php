<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Art Work Comparison</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        h2, h4, h5 {
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        .results {
            margin-top: 20px;
        }

        .common-text {
            background-color: #f0f0f0;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .highlight {
            color: green;
        }

        .difference {
            color: red;
        }

        .card-body pre {
            white-space: pre-wrap;
        }
    </style>
</head>

<body>
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo d-flex align-items-center">
                <span class="d-none d-lg-block">RMS</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>&nbsp;&nbsp;&nbsp;<h3><b>Request Management System</b></h3>
        </div>
        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
                        <span class="d-none d-md-block dropdown-toggle ps-2">Vinay Mali</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6>Vinay Mali</h6>
                            <span>Artwork</span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>

    <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="index.html">
      <i class="bi bi-grid"></i>
      <span>Dashboard</span>
    </a>
  </li><!-- End Dashboard Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-menu-button-wide"></i><span>Masters</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="test.php">
          <i class="bi bi-circle"></i><span>Activity Master</span>
        </a>
      </li>
      <li>
        <a href="test_art.php">
          <i class="bi bi-circle"></i><span>Artwork</span>
        </a>
      </li>
      <li>
        <a href="user-mastergroup1.php">
          <i class="bi bi-circle"></i><span>User Group</span>
        </a>
      </li>
      <!-- <li>
        <a href="ticket_activity.php">
          <i class="bi bi-circle"></i><span>Ticket Activity</span>
        </a>
      </li> -->
     


    <!--<li>
        <a href="components-cards.html">
          <i class="bi bi-circle"></i><span>Cards</span>
        </a>
      </li>
      <li>
        <a href="components-carousel.html">
          <i class="bi bi-circle"></i><span>Carousel</span>
        </a>
      </li>
      <li>
        <a href="components-list-group.html">
          <i class="bi bi-circle"></i><span>List group</span>
        </a>
      </li>
      <li>
        <a href="components-modal.html">
          <i class="bi bi-circle"></i><span>Modal</span>
        </a>
      </li>
      <li>
        <a href="components-tabs.html">
          <i class="bi bi-circle"></i><span>Tabs</span>
        </a>
      </li>
      <li>
        <a href="components-pagination.html">
          <i class="bi bi-circle"></i><span>Pagination</span>
        </a>
      </li>
      <li>
        <a href="components-progress.html">
          <i class="bi bi-circle"></i><span>Progress</span>
        </a>
      </li>
      <li>
        <a href="components-spinners.html">
          <i class="bi bi-circle"></i><span>Spinners</span>
        </a>
      </li>
      <li>
        <a href="components-tooltips.html">
          <i class="bi bi-circle"></i><span>Tooltips</span>
        </a>
      </li>-->
    </ul>
  </li><!-- End Components Nav -->
<!--
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-journal-text"></i><span>Forms</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="forms-elements.html">
          <i class="bi bi-circle"></i><span>Form Elements</span>
        </a>
      </li>
      <li>
        <a href="forms-layouts.html">
          <i class="bi bi-circle"></i><span>Form Layouts</span>
        </a>
      </li>
      <li>
        <a href="forms-editors.html">
          <i class="bi bi-circle"></i><span>Form Editors</span>
        </a>
      </li>
      <li>
        <a href="forms-validation.html">
          <i class="bi bi-circle"></i><span>Form Validation</span>
        </a>
      </li>
    </ul>
  </li>  --><!-- End Forms Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-layout-text-window-reverse"></i><span>Tables</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="tables-general.html">
          <i class="bi bi-circle"></i><span>General Tables</span>
        </a>
      </li>
      <li>
        <a href="tables-data.html">
          <i class="bi bi-circle"></i><span>Data Tables</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Tables Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-bar-chart"></i><span>Charts</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="charts-chartjs.html">
          <i class="bi bi-circle"></i><span>Chart.js</span>
        </a>
      </li>
      <li>
        <a href="charts-apexcharts.html">
          <i class="bi bi-circle"></i><span>ApexCharts</span>
        </a>
      </li>
      <li>
        <a href="charts-echarts.html">
          <i class="bi bi-circle"></i><span>ECharts</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Charts Nav -->
<!-- 
  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-gem"></i><span>Icons</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="icons-bootstrap.html">
          <i class="bi bi-circle"></i><span>Bootstrap Icons</span>
        </a>
      </li>
      <li>
        <a href="icons-remix.html">
          <i class="bi bi-circle"></i><span>Remix Icons</span>
        </a>
      </li>
      <li>
        <a href="icons-boxicons.html">
          <i class="bi bi-circle"></i><span>Boxicons</span>
        </a>
      </li>
    </ul>
  </li> --><!-- End Icons Nav -->

  <li class="nav-heading">Pages</li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="user_profile1.php">
      <i class="bi bi-person"></i>
      <span>Profile</span>
    </a>
  </li><!-- End Profile Page Nav -->

  <!-- <li class="nav-item">
    <a class="nav-link collapsed" href="users-profile-aka.php">
      <i class="bi bi-person"></i>
      <span>Profile Management</span>
    </a>
  </li> -->

 

 
  

  

</ul>

</aside><!-- End Sidebar-->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Art Work Comparison</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Art Work</a></li>
                    <li class="breadcrumb-item active"></li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <section class="section">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Previous Version</h5>
                                            <label for="file1">Choose first file (image/pdf/text):</label>
                                            <input type="file" name="file1" id="file1" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">New Version</h5>
                                            <label for="file2">Choose second file (image/pdf/text):</label>
                                            <input type="file" name="file2" id="file2" required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-body">
                                    <input type="submit" value="Upload and Process">
                                </div>
                            </div>
                        </section>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        function extractTextFromFile($filePath) {
                            $output = '';
                            $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
                            $textFilePath = 'uploads/' . basename($filePath) . '.txt'; // Define the text file path
                    
                            if ($fileExtension == 'pdf') {
                                shell_exec("pdftotext \"$filePath\" \"$textFilePath\"");
                                $output = file_get_contents($textFilePath);
                            } elseif (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                                // Use appropriate OCR method for images
                                // For example, if you're using Tesseract OCR:
                                $output = shell_exec("tesseract \"$filePath\" stdout");
                            } else {
                                // For other file types, simply read the content
                                $output = file_get_contents($filePath);
                            }
                    
                            return $output;
                        }
                    
                    
                    
                        // Rest of the code for file comparison...
                    

                        function highlightText($text, $words, $class) {
                            foreach ($words as $word) {
                                $text = preg_replace("/\b($word)\b/i", "<span class='$class'>$1</span>", $text);
                            }
                            return $text;
                        }

                        function findCommonAndDifferences($text1, $text2) {
                            $words1 = preg_split('/\s+/', $text1);
                            $words2 = preg_split('/\s+/', $text2);
                            $common = array_intersect($words1, $words2);
                            $diff1 = array_diff($words1, $words2);
                            $diff2 = array_diff($words2, $words1);

                            return [
                                'common' => $common,
                                'diff1' => $diff1,
                                'diff2' => $diff2
                            ];
                        }

                        $uploadDir = 'uploads/';
                        
                        if (!is_dir($uploadDir)) {
                            mkdir($uploadDir, 0777, true);
                        }

                        $file1Path = $uploadDir . basename($_FILES['file1']['name']);
                        $file2Path = $uploadDir . basename($_FILES['file2']['name']);

                        move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
                        move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);

                        $ocrText1 = extractTextFromFile($file1Path);
                        $ocrText2 = extractTextFromFile($file2Path);

                        $results = findCommonAndDifferences($ocrText1, $ocrText2);

                        $highlightedText1 = highlightText($ocrText1, $results['common'], 'highlight');
                        $highlightedText1 = highlightText($highlightedText1, $results['diff1'], 'difference');

                        $highlightedText2 = highlightText($ocrText2, $results['common'], 'highlight');
                        $highlightedText2 = highlightText($highlightedText2, $results['diff2'], 'difference');

                        echo "<div class='results'>";
                        echo "<h4>Content of First File:</h4>";
                        echo "<pre>" . $highlightedText1 . "</pre>";
                        echo "<h4>Content of Second File:</h4>";
                        echo "<pre>" . $highlightedText2 . "</pre>";
                        echo "<h4>Common Text:</h4>";
                        echo "<div class='common-text'><pre>" . implode(' ', $results['common']) . "</pre></div>";
                        echo "<h4>Different Text in First File:</h4>";
                        echo "<div class='common-text'><pre class='difference'>" . implode(' ', $results['diff1']) . "</pre></div>";
                        echo "<h4>Different Text in Second File:</h4>";
                        echo "<div class='common-text'><pre class='difference'>" . implode(' ', $results['diff2']) . "</pre></div>";
                        echo "</div>";
                    }
                    ?>
                </div>
            </div>
        </section>
    </main>
</body>

</html>
