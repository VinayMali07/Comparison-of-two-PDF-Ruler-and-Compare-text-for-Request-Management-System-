<?php
session_start();
include('includes/config.php');


// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Create User Group
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_group_name = $_POST['user_group_name'];
    $creation_user = $_POST['creation_user'];
    $last_modification_user = $_POST['last_modification_user'];
    
    $creation_time = date('Y-m-d H:i:s');
    $last_modification_time = date('Y-m-d H:i:s');
    
    $sql = "INSERT INTO user_group_master (user_group_name, creation_user, last_modification_user, creation_time, last_modification_time) 
            VALUES ('$user_group_name', '$creation_user', '$last_modification_user', '$creation_time', '$last_modification_time')";
    
    if ($mysqli->query($sql) === TRUE) {
        echo'<script>alert("User Group Created successfully!");</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
    }
}

// Display User Groups
$sql = "SELECT * FROM user_group_master";
$result = $mysqli->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Pages / User Group</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
  <main>
    <div class="container">
      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 d-flex flex-column align-items-center justify-content-center">
              <div class="d-flex justify-content-center py-4"></div>
              <div class="card mb-3">
                <div class="card-body">
                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">User Groups Page</h5>
                    <p class="text-center small">User Group information</p>
                  </div>
                  <form class="row g-3 needs-validation" action="" method="POST" novalidate>
                    <div class="col-12">
                      <label for="user_group_name" class="form-label">User Group Name</label>
                      <div class="input-group has-validation">
                        <input type="text" name="user_group_name" class="form-control" id="user_group_name" required>
                        <div class="invalid-feedback">Please enter your group name.</div>
                      </div>
                    </div>
                    <div class="col-12">
                      <label for="creation_user" class="form-label">Creation User</label>
                      <input type="text" name="creation_user" class="form-control" id="creation_user" required>
                      <div class="invalid-feedback">Enter Creation User</div>
                    </div>
                    <div class="col-12">
                      <label for="last_modification_user" class="form-label">Last Modification User</label>
                      <div class="input-group has-validation">
                        <input type="text" name="last_modification_user" class="form-control" id="last_modification_user" required>
                        <div class="invalid-feedback">Please enter Modification user.</div>
                      </div>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-primary w-100" type="submit">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
              <div>
                <h2>User Groups</h2>
                <?php
                if ($result->num_rows > 0) {
                    echo "<table class='table table-bordered'>
                            <tr>
                                <th>User Group ID</th>
                                <th>User Group Name</th>
                                <th>Creation User</th>
                                <th>Last Modification User</th>
                                <th>Creation Time</th>
                                <th>Last Modification Time</th>
                            </tr>";
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $row["user_group_oid"]. "</td>
                                <td>" . $row["user_group_name"]. "</td>
                                <td>" . $row["creation_user"]. "</td>
                                <td>" . $row["last_modification_user"]. "</td>
                                <td>" . $row["creation_time"]. "</td>
                                <td>" . $row["last_modification_time"]. "</td>
                              </tr>";
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }

                $mysqli->close();
                ?>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/js/main.js"></script>
</body>
</html>
