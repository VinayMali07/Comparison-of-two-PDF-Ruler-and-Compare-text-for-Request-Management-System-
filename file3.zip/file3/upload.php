<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Function to handle file upload and OCR processing
    function processImage($fileKey) {
        // Check if the file was uploaded without errors
        if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] == 0) {
            $filename = $_FILES[$fileKey]['name'];
            $filepath = 'uploads/' . $filename;

            // Move the uploaded file to the designated directory
            if (move_uploaded_file($_FILES[$fileKey]['tmp_name'], $filepath)) {
                // Perform OCR using Tesseract
                $output = shell_exec("tesseract $filepath stdout");

                // Return the OCR output
                return $output;
            } else {
                return "Error moving the uploaded file.";
            }
        } else {
            return "Error uploading the file.";
        }
    }

    // Create the uploads directory if it doesn't exist
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true);
    }

    // Process both images
    $ocrText1 = processImage('file1');
    $ocrText2 = processImage('file2');
    ?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>OCR Results</title>
    </head>
    <body>
        <h2>OCR Results for First Image:</h2>
        <pre><?php echo htmlspecialchars($ocrText1); ?></pre>
        
        <h2>OCR Results for Second Image:</h2>
        <pre><?php echo htmlspecialchars($ocrText2); ?></pre>
        
        <a href="artwork.php">Upload more images</a>
    </body>
    </html>
    
    <?php
}
?>
