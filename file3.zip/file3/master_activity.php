<?php
session_start();
include('includes/config.php');


if(isset($_GET['del']))
{
	$oid=intval($_GET['del']);
	$adn="delete from master_activity where oid=?";
		$stmt= $mysqli->prepare($adn);
		$stmt->bind_param('i',$oid);
        $stmt->execute();
        $stmt->close();	   
        echo "<script>alert('Data Deleted');</script>" ;
}
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Components </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <script>
//   function saveData() 
//   {
//     const styleName = document.getElementById('level').value;
//     const cssProperty = document.getElementById('parent_oid').value;
//     const value = document.getElementById('description').value;

//       if (styleName && cssProperty && value) 
//       {
//         const xhr = new XMLHttpRequest();
//         xhr.open('POST', 'save_data.php', true);
//         xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
//         xhr.onreadystatechange = function() {
//           if (xhr.readyState == 4 && xhr.status == 200) {
//             if (xhr.responseText == 'success') {
//                               // Clear the input fields
//               document.getElementById('level').value = '';
//               document.getElementById('parent_oid').value = '';
//               document.getElementById('description').value = '';
//               // Reload the data
//               // loadData();
//             } else {
//               alert('Failed to save data.');
//             }
//             }
//             };
//             xhr.send(level=${level}&parent_oid=${parent_oid}&description=${description});
//             } else {
//             alert('Please fill all fields.');
//       }
//   }  
  </script>
  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <span class="d-none d-lg-block">RMS</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn">&nbsp; Request Management System </i>
    </div><!-- End Logo -->

    <div class="search-bar">
      
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

       

        <li class="nav-item dropdown">

          
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            

            

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

         

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Kevin Anderson</h6>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="index.html">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Masters</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="master_activity.php">
              <i class="bi bi-circle"></i><span>Activity Master</span>
            </a>
          </li>
          <li>
            <a href="artwork.php">
              <i class="bi bi-circle"></i><span>Artwork</span>
            </a>
          </li>
          <li>
            <a href="user_group_master.php">
              <i class="bi bi-circle"></i><span>User Group</span>
            </a>
          </li>
          <li>
            <a href="components-breadcrumbs.html">
              <i class="bi bi-circle"></i><span>Breadcrumbs</span>
            </a>
          </li>
          <li>
            <a href="components-buttons.html">
              <i class="bi bi-circle"></i><span>Buttons</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link collapsed" href="pages-blank.php">
              <i class="bi bi-file-earmark"></i>
              <span>Master Activity 2</span>
            </a>
          </li><!-- End Blank Page Nav -->
          </ul>
      </li>

      <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.html">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li><!-- End Profile Page Nav -->

      


      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.html">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Master Activity</h1>
      
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!--hi use thi-->
<!-- Primary Color Bordered Table -->
<h5 class="card-title">Master Activity</h5>
<table class="table table-bordered border-primary">
  <thead>
    <tr>
      <th>Sno.</th>
      <th> Level</th>
      <th>Parent</th>
      <th>Description</th>
      
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php	
    //$aid=$_SESSION['id'];
    $ret="select * from master_activity";
    $stmt= $mysqli->prepare($ret) ;
    //$stmt->bind_param('i',$aid);
    $stmt->execute() ;//ok
    $res=$stmt->get_result();
    $cnt=1;
    while($row=$res->fetch_object())
        {
          ?>
    <tr>
    <td><?php echo $row->oid;?></td>
    <td><?php echo $row->level;?></td>
    <td><?php echo $row->parent_oid;?></td>
    <td><?php echo $row->description;?></td>
    <?php

$cnt=$cnt+1;
     }
     ?> 

    
<td> 
    <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ExtralargeModal"> -->
    <i class="ri-edit-box-line" name="edit_button" id="edit_button"  data-bs-target="#ExtralargeModal" data-bs-toggle="modal"></i> &nbsp;&nbsp;
<!-- </button>   -->
<div class="modal fade" id="ExtralargeModal" tabindex="-1">
                <div class="modal-dialog modal-xl">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit/Update Activity Master</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                  <form action="#" method="POST">
                    <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">  &nbsp;&nbsp; &nbsp;&nbsp; <b> Level :</b> </label>
                  <div class="col-sm-10">
                  <select class="form-select" aria-label="multiple select example" required name="edit_parent">
                    <option value="">select option</option>
                    <?php 
                    $query ="SELECT * FROM master_activity";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->level;?>"><?php echo $row->level;?></option>
                    <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                 <label class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b> Parent :</b></label>
                  <div class="col-sm-10">
                    <select class="form-select" aria-label="multiple select example" required name="edit_parent">
                    <option value="">select option</option>
                    <?php 
                    $query ="SELECT * FROM master_activity";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->parent_oid;?>"><?php echo $row->parent_oid;?></option>
                    <?php } ?>
                    </select>
                  </div>
                </div>


                <div class="row mb-2">
               <label for="inputPassword" class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b> Description :</b></label>
                  <div class="col-sm-10">
                    <textarea class="form-control" style="height: 100px"></textarea>
                  </div>
                </div>




                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit"  id="submit"class="btn btn-primary">Save </button>
                    </div>
                  </div>
                </div>
              </div>
                   
              
              <a href="master_activity.php?del=<?php echo $row->oid;?>" onclick="return confirm("Do you want to delete");"> <i class="ri-delete-bin-line"></i></a>
            </td>
             
              </form><!-- End Extra Large Modal-->
              <!--php -->
</tr>
                    

                   
                    
                            
                        
                    </tbody>

  
                </table>
<!-- End Primary Color Bordered Table -->
                    


            </div>
          </div>

        </div>
        
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <!-- Extra Large Modal -->
              <div class="pagetitle">
                  <h1>Add New Master Activity</h1>
                    </div>

              <button type="button" name="Add_button" id="Add_button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ExtralargeModal1">
                Add New Master Activity
              </button>
              
              <div class="modal fade" id="ExtralargeModal1" tabindex="-1">
                <div class="modal-dialog modal-xl">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Add Master Activity</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                     <form method="POST" action="#">
                    <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Level :</b></label>
                  <div class="col-sm-10">

                  <select class="form-select" aria-label="multiple select example" required name="level" id="level">
                      <option value="">select option</option>
                      <?php 
                    $query ="SELECT * FROM activity_level";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->levels;?>"><?php echo $row->levels;?></option>
                    <?php } ?>
                    </select>
                    <!-- <input type="text" name="level" id="level" class="form-control"> -->                     
                  </div>
                </div>
              

                <div class="row mb-5">
                 <label class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Parent :</b></label>
                  <div class="col-sm-10">
                    <select class="form-select" aria-label="multiple select example" required name="parent_oid" id="parent_oid">
                      <option value="">select option</option>
                      <?php 
                    $query ="SELECT * FROM master_activity";
                    $stmt2 = $mysqli->prepare($query);
                    $stmt2->execute();
                    $res=$stmt2->get_result();
                    while($row=$res->fetch_object())
                    {
                    ?>
                    <option value="<?php echo $row->parent_oid;?>"><?php echo $row->parent_oid;?></option>
                    <?php } ?>
                    </select>
                  </div>
                </div>


                <div class="row mb-3">
               <label for="inputPassword" class="col-sm-2 col-form-label"> &nbsp;&nbsp; &nbsp;&nbsp;<b>Description :</b></label>
                  <div class="col-sm-10">
                  <input type="text" name="description" id="description" class="form-control">
                  </div>
                </div>


                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                      <button type="submit"  name="submit"   class="btn btn-primary">Save</button>
                      <!-- <button class="btn btn-success" onclick="saveData()">Add Master</button> -->
                    </div>
                  </div>
                </div>
                    </form>
              </div><!-- End Extra Large Modal-->
              <?php
                //session_start();
                include('includes/config.php');
                //include('includes/checklogin.php');
                //check_login();
             //include('includes/checklogin.php');
//check_login();

                    if (isset($_POST['submit'])) 
                    {
                    $level = $_POST['level'];
                    $parent_oid = $_POST['parent_oid'];
                    $description = $_POST['description'];

                    // Check if parent_oid exists
                    $sql = "SELECT description FROM master_activity WHERE description=?";
                    $stmt1 = $mysqli->prepare($sql);
                    $stmt1->bind_param('s', $description); // Changed $level to $parent_oid
                    $stmt1->execute();
                    $stmt1->store_result(); 
                    $stmt->fetch();
                    $stmt->close();
                    $row_cnt = $stmt1->num_rows;

                    if ($row_cnt > 0) {
                      // Insert new record
                      $query = "INSERT INTO master_activity (level, parent_oid, description) VALUES (?, ?, ?)";
                    $stmt = $mysqli->prepare($query);
                    $stmt->bind_param('sss', $level, $parent_oid, $description); // 'iis' because description is a string
                    $stmt->execute();

                    echo "<script>alert('Activity Masters has been added successfully');</script>";
                     
                    } else {

                      echo "<script>alert('level does not exist');</script>";
                      
                      
                    }
                    }
?>

                


  <!--button end-->
            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
   
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>