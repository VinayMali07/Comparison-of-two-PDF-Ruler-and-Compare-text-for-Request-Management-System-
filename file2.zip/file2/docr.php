<?php
include('class.pdf2text.php');
include('includes/config.php');
require('fpdf/fpdf.php');

function compareText($text1, $text2) {
    // Remove extra whitespaces and split into words
    $words1 = str_word_count($text1, 1);
    $words2 = str_word_count($text2, 1);
    
    $result1 = [];
    $result2 = [];
    $common = [];
    $diff1 = [];
    $diff2 = [];

    foreach ($words1 as $word) {
        if (in_array($word, $words2)) {
            $result1[] = "<span class='common'>" . htmlspecialchars($word) . "</span>";
            $common[] = $word;
        } else {
            $result1[] = "<span class='different'>" . htmlspecialchars($word) . "</span>";
            $diff1[] = $word;
        }
    }

    foreach ($words2 as $word) {
        if (!in_array($word, $words1)) {
            $result2[] = "<span class='different'>" . htmlspecialchars($word) . "</span>";
            $diff2[] = $word;
        }
    }

    if (empty($common) && empty($diff1) && empty($diff2)) {
        return [
            'highlightedText1' => '',
            'highlightedText2' => '',
            'common' => ['hello'],
            'diff1' => ['good morning'],
            'diff2' => ['hi its vins']
        ];
    }

    return [
        'highlightedText1' => implode(' ', $result1),
        'highlightedText2' => implode(' ', $result2),
        'common' => array_values($common),
        'diff1' => array_values($diff1),
        'diff2' => array_values($diff2)
    ];
}

function generatePDF($text1, $text2, $results) {
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetMargins(20, 20); // Top and side margins

    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Comparison Results', 0, 1, 'C');

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Text from File 1:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, $text1);
    $pdf->Ln(10);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Text from File 2:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, $text2);
    $pdf->Ln(10);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Common Words:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    if (isset($results['common']) && !empty($results['common'])) {
        foreach ($results['common'] as $word) {
            $pdf->Cell(0, 10, $word, 0, 1);
        }
    } else {
        $pdf->Cell(0, 10, "hello", 0, 1);
    }
    $pdf->Ln(10);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Differences in File 1:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    if (isset($results['diff1']) && !empty($results['diff1'])) {
        foreach ($results['diff1'] as $word) {
            $pdf->Cell(0, 10, $word, 0, 1);
        }
    } else {
        $pdf->Cell(0, 10, "good morning", 0, 1);
    }
    $pdf->Ln(10);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Differences in File 2:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    if (isset($results['diff2']) && !empty($results['diff2'])) {
        foreach ($results['diff2'] as $word) {
            $pdf->Cell(0, 10, $word, 0, 1);
        }
    } else {
        $pdf->Cell(0, 10, "hi its vins", 0, 1);
    }

    $pdf->Output('D', 'ComparisonResults.pdf');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['comparepdfs'])) {
        if ($_FILES['file1']['type'] == "application/pdf" && $_FILES['file2']['type'] == "application/pdf") {
            $fileTmpPath1 = $_FILES['file1']['tmp_name'];
            $fileTmpPath2 = $_FILES['file2']['tmp_name'];
            $uploadsDir = 'uploads';
            if (!is_dir($uploadsDir)) {
                mkdir($uploadsDir, 0777, true);
            }
            $timestamp = time();
            $filePath1 = "{$uploadsDir}/pdf1-{$timestamp}.pdf";
            $filePath2 = "{$uploadsDir}/pdf2-{$timestamp}.pdf";
            if (move_uploaded_file($fileTmpPath1, $filePath1) && move_uploaded_file($fileTmpPath2, $filePath2)) {
                $pdf1 = new PDF2Text();
                $pdf1->setFilename($filePath1);
                $pdf1->decodePDF();
                $text1 = $pdf1->output();
                $pdf2 = new PDF2Text();
                $pdf2->setFilename($filePath2);
                $pdf2->decodePDF();
                $text2 = $pdf2->output();
                $results = compareText($text1, $text2);

                // Display comparison results in HTML for user reference
                echo "<div class='container'>";
                echo "<h3>Comparison Result</h3>";
                echo "<table>";
                echo "<tr><th>File 1</th><th>File 2</th></tr>";
                echo "<tr><td>{$results['highlightedText1']}</td><td>{$results['highlightedText2']}</td></tr>";
                echo "</table>";
                echo "<h4>Common Words</h4>";
                echo "<p>" . implode(', ', $results['common']) . "</p>";
                echo "<h4>Differences in File 1</h4>";
                echo "<p>" . implode(', ', $results['diff1']) . "</p>";
                echo "<h4>Differences in File 2</h4>";
                echo "<p>" . implode(', ', $results['diff2']) . "</p>";
                echo "<form method='post' action=''>";
                echo "<input type='hidden' name='text1' value='" . htmlspecialchars($text1) . "'>";
                echo "<input type='hidden' name='text2' value='" . htmlspecialchars($text2) . "'>";
                echo "<input type='hidden' name='results' value='" . htmlspecialchars(json_encode($results)) . "'>";
                echo "<button type='submit' name='generate_pdf' class='btn'>Download Comparison as PDF</button>";
                echo "</form>";
                echo "</div>";

                // Uncomment the following line if you want to automatically generate PDF upon comparison
                // generatePDF($text1, $text2, $results);
            } else {
                echo "<p class='message'>Error uploading files. Please try again.</p>";
            }
        } else {
            echo "<p class='message'>Both files must be PDF format</p>";
        }
    } elseif (isset($_POST['generate_pdf'])) {
        $text1 = $_POST['text1'];
        $text2 = $_POST['text2'];
        $results = json_decode($_POST['results'], true);
        generatePDF($text1, $text2, $results);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compare PDFs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #444;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .common {
            background-color: #d4edda;
            color: #155724;
        }
        .different {
            background-color: #f8d7da;
            color: #721c24;
        }
        .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            display: inline-block;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="btn btn-info">Compare PDFs</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <h4 class="btn btn-info">Old Version</h4>
            <input type="file" name="file1" accept=".pdf" required>
            <h4 class="btn btn-info">New Version</h4>
            <input type="file" name="file2" accept=".pdf" required>
            <button type="submit" name="comparepdfs" class="btn">Compare PDFs</button>
        </form>
        <!-- PHP echoed content goes here -->
    </div>
</body>
</html>
