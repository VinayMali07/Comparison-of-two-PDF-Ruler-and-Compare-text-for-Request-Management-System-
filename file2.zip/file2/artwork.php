<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">



  <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        h2, h4, h5 {
            color: #333;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="file"] {
            margin-bottom: 10px;
        }
        .results {
            margin-top: 20px;
        }
        .common-text {
            background-color: #f0f0f0;
            padding: 10px;
            border: 1px solid #ccc;
        }
        .highlight {
            color: green;
        }
    </style>


  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <span class="d-none d-lg-block">  RMS  </span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>&nbsp;&nbsp;&nbsp;<h3><b>Request Management System</b></h3>
    </div><!-- End Logo -->

    
     
      
    

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

       

        
        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">Vinay Mali</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Vinay Mali</h6>
              <span>Artwork</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            
            <li>
              <hr class="dropdown-divider">
            </li>

           
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="logout.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="index.html">
      <i class="bi bi-grid"></i>
      <span>Dashboard</span>
    </a>
  </li><!-- End Dashboard Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
      <i class="bi bi-menu-button-wide"></i><span>Masters</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
      <li>
        <a href="test.php">
          <i class="bi bi-circle"></i><span>Activity Master</span>
        </a>
      </li>

      <!-- <li>
            <a href="artwork.php">
              <i class="bi bi-circle"></i><span>Artwork</span>
            </a>
          </li> -->
          <li>
            <a href="user_group_master.php">
              <i class="bi bi-circle"></i><span>User Group</span>
            </a>
          </li>

      <li>
        <a href="ocr.php">
          <i class="bi bi-circle"></i><span>Artwork image and Text</span>
        </a>
      </li>
      <li>
        <a href="aocr.php">
          <i class="bi bi-circle"></i><span>Atrwork image and Text report</span>
        </a>
      </li>
      <li>
        <a href="docr.php">
          <i class="bi bi-circle"></i><span>Artwork PDF Compare</span>
        </a>
      </li>
      <li>
        <a href="gocr.php">
          <i class="bi bi-circle"></i><span>Image Ruler</span>
        </a>
      </li>
    
    </ul>
  </li><!-- End Components Nav -->

 

 
  

  

</ul>

</aside>
  
        
`
    
      
`



  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Art Work Comparison</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Art Work</a></li>
          <li class="breadcrumb-item active"> </li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

          <form action="#" method="post" enctype="multipart/form-data">

          <section class="section">
      <div class="row">
        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
            <div>
            <h5 class="card-title">Previous Version</h5>
            <label for="file1">Choose first image:</label>
            <input type="file" name="file1" id="file1" required>
        </div>
                 <br><br>
                <!-- <input type="submit" value="Upload and Process"> -->

                

                <br><br><br><br>
               
            </div>
          </div>

        </div>

        <div class="col-lg-6">

          <div class="card">
            <div class="card-body">
             
        <div>
            <h5 class="card-title">New Version</h5>
            <label for="file2">Choose second image:</label>
            <input type="file" name="file2" id="file2" required>
        </div>
                <br><br>

                
        <!-- <input type="submit" value="Upload and Process"> -->
                 
                 <br><br>
                 <br><br>
        

            </div>
          </div>




        </div>
        <a href="artwork.php">Upload more images</a>
      </div>

      <div class="card">
            <div class="card-body">
            <div>
            <br><br>
                <input type="submit" value="Upload and Process">
        </div>
                 
        </form>
                

                <br><br><br><br>
               
            </div>
          </div>
    </section>


           




    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        function extractTextFromFile($filePath) {
            $output = '';
            $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
            
            if ($fileExtension == 'pdf') {
                $tempImage = 'uploads/temp_image.png';
                shell_exec("pdftoppm -singlefile -png $filePath uploads/temp_image");
                $output = shell_exec("tesseract $tempImage stdout");
                unlink($tempImage);
            } else {
                $output = shell_exec("tesseract $filePath stdout");
            }
            
            return $output;
        }

        function findCommonText($text1, $text2) {
            $words1 = preg_split('/\s+/', $text1);
            $words2 = preg_split('/\s+/', $text2);
            $commonWords = array_intersect($words1, $words2);
            $highlightedCommonWords = array_map(function($word) {
                return "<span class='highlight'>$word</span>";
            }, $commonWords);

            $commonText = implode(' ', $highlightedCommonWords);
            return $commonText;
        }

        $uploadDir1 = 'uploads1/';
        $uploadDir2 = 'uploads2/';
        
        if (!is_dir($uploadDir1)) {
            mkdir($uploadDir1, 0777, true);
        }
        if (!is_dir($uploadDir2)) {
            mkdir($uploadDir2, 0777, true);
        }

        $file1Path = $uploadDir1 . basename($_FILES['file1']['name']);
        $file2Path = $uploadDir2 . basename($_FILES['file2']['name']);

        move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
        move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);

        $ocrText1 = extractTextFromFile($file1Path);
        $ocrText2 = extractTextFromFile($file2Path);

        $commonText = findCommonText($ocrText1, $ocrText2);

        echo "<div class='results'>";
        echo "<h4>Conten of First Image:</h4>";
        echo "<pre>" . htmlspecialchars($ocrText1) . "</pre>";
        echo "<h4> Content of Second Image:</h4>";
        echo "<pre>" . htmlspecialchars($ocrText2) . "</pre>";
        echo "<h4>Common Text:</h4>";
        echo "<div class='common-text'><pre>" . $commonText . "</pre></div>";
        echo "</div>";
    }
    ?>


            

            
                 
          

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

         

                

         

         

        </div><!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    
    
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>