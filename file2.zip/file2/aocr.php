
<?php
session_start();
include('includes/config.php');
require('fpdf/fpdf.php');

// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

// Upload files and save names to database
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file1']) && isset($_FILES['file2'])) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $file1Path = $uploadDir . basename($_FILES['file1']['name']);
    $file2Path = $uploadDir . basename($_FILES['file2']['name']);
    move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
    move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);

    // Get the next image number
    $result = mysqli_query($mysqli, "SELECT MAX(img_id) as max_id FROM images");
    $next_id = 0;
    if ($result) {
        $row = mysqli_fetch_array($result);
        $next_id = $row['max_id'] !== NULL ? $row['max_id'] + 1 : 1;
    }
    // Save file names to database
    $img1_name = "img1-" . $next_id;
    $img2_name = "img2-" . $next_id;
    mysqli_query($mysqli, "INSERT INTO images (img1, img2) VALUES ('$img1_name', '$img2_name')");

    // Extract text and compare
    $ocrText1 = extractTextFromFile($file1Path);
    $ocrText2 = extractTextFromFile($file2Path);

    $results = findCommonAndDifferences($ocrText1, $ocrText2);

    $highlightedText1 = highlightText(strip_tags($ocrText1), $results['common'], 'highlight');
    $highlightedText1 = highlightText(strip_tags($highlightedText1), $results['diff1'], 'difference');

    $highlightedText2 = highlightText(strip_tags($ocrText2), $results['common'], 'highlight');
    $highlightedText2 = highlightText(strip_tags($highlightedText2), $results['diff2'], 'difference');

    // Generate PDF
    if (isset($_POST['generate_pdf'])) {
        generatePDF($highlightedText1, $highlightedText2, $results);
    }
}

function extractTextFromFile($filePath) {
    $output = '';
    $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
    $textFilePath = 'uploads/' . basename($filePath) . '.txt'; // Define the text file path

    if ($fileExtension == 'pdf') {
        shell_exec("pdftotext \"$filePath\" \"$textFilePath\"");
        if (file_exists($textFilePath)) {
            $output = file_get_contents($textFilePath);
        }
    } elseif (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
        $output = shell_exec("tesseract \"$filePath\" stdout");
    } else {
        $output = file_get_contents($filePath);
    }

    return $output;
}

function highlightText($text, $words, $class) {
    foreach ($words as $word) {
        $word = preg_quote($word, '/');
        $text = preg_replace("/\b($word)\b/", "<span class='$class'>$1</span>", $text);
    }
    return $text;
}

function findCommonAndDifferences($text1, $text2) {
    $words1 = preg_split('/\s+/', $text1);
    $words2 = preg_split('/\s+/', $text2);
    $common = array_intersect($words1, $words2);
    $diff1 = array_diff($words1, $words2);
    $diff2 = array_diff($words2, $words1);

    return [
        'common' => $common,
        'diff1' => $diff1,
        'diff2' => $diff2
    ];
}

function generatePDF($text1, $text2, $results) {
    // Clear any previous output
    ob_clean();

    $pdf = new FPDF();
    $pdf->AddPage();

    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Comparison Results', 0, 1, 'C');

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Text from File 1:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, strip_tags($text1));

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Text from File 2:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, strip_tags($text2));

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Common Words:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, implode(', ', $results['common']));

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Differences in File 1:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, implode(' ', $results['diff1']));

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Differences in File 2:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 10, implode(' ', $results['diff2']));

    $pdf->Output('F', 'uploads/ComparisonResults.pdf');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Art Work Comparison</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        h2, h4, h5 {
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        .results {
            margin-top: 20px;
        }

        .common-text {
            background-color: #f0f0f0;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .highlight {
            color: green;
            font-weight: bold;
        }

        .difference {
            color: red;
        }

        .img-preview {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
            border: 1px solid #ccc;
        }

        .btn-download {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
    <div class="col-lg-12">
        <h2 class="btn btn-info">Art Work Image Comparison</h2><br><br>
        <form method="post" enctype="multipart/form-data">
        <h5 class="btn btn-info">    New Version   </h5>
            <input type="file" name="file1" required>
            <h5  class="btn btn-info">Previous Version</h5>
            <input type="file" name="file2" required> 
            <button type="submit" name="generate_pdf" class="btn btn-primary">Upload and Compare </button>
        </form>
        </div>

        <?php if (isset($highlightedText1) && isset($highlightedText2)): ?>
            <div class="results">
                <h4 class="btn btn-info">Comparison Results:</h4>
                <div class="row">
                    <div class="col-md-6">
                        <h5>Text from File 1:</h5>
                        <div class="common-text">
                            <?php echo $highlightedText1; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5>Text from File 2:</h5>
                        <div class="common-text">
                            <?php echo $highlightedText2; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <h5>Common Words:</h5>
                        <p><?php echo implode(', ', $results['common']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h5>Differences:</h5>
                        <p>File 1: <?php echo implode(' ', $results['diff1']); ?></p>
                        <p>File 2: <?php echo implode(' ', $results['diff2']); ?></p>
                    </div>
                </div>
            </div>

            <hr>

            <div class="row">
                <div class="col-md-6">
                    <h4>Preview of Images:</h4>
                    <img src="<?php echo $file1Path; ?>" class="img-preview" alt="Image 1">
                   
                </div>

                <div class="col-md-6">
                    <h4>Preview of Images:</h4>
                   
                    <img src="<?php echo $file2Path; ?>" class="img-preview" alt="Image 2">
                </div>
                <div class="col-md-6">
                    <h4>Download Options:</h4>
                    <a href="<?php echo $file1Path; ?>" class="btn btn-primary" download>Download Image 1</a>
                    <a href="<?php echo $file2Path; ?>" class="btn btn-primary" download>Download Image 2</a>
                    <a href="uploads/ComparisonResults.pdf" class="btn btn-primary btn-download" download>Download Comparison PDF</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/quill/quill.min.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>
