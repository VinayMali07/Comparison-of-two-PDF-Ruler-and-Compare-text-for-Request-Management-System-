<?php
session_start();
include('includes/config.php');

// Check connection
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

// Upload files and save names to database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $file1Path = $uploadDir . basename($_FILES['file1']['name']);
    $file2Path = $uploadDir . basename($_FILES['file2']['name']);
    move_uploaded_file($_FILES['file1']['tmp_name'], $file1Path);
    move_uploaded_file($_FILES['file2']['tmp_name'], $file2Path);

    // Get the next image number
    $result = mysqli_query($mysqli, "SELECT MAX(img_id) as max_id FROM images");
    $next_id = 0;
    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row['max_id'] !== NULL) {
            $next_id = $row['max_id'] + 1;
        } else {
            $next_id = 1; // or a default value
        }
    }

    // Save file names to database
    $img1_name = "img1-" . $next_id;
    $img2_name = "img2-" . $next_id;
    mysqli_query($mysqli, "INSERT INTO images (img1, img2) VALUES ('$img1_name', '$img2_name')");

    // Display uploaded files
    echo "<div class='uploaded-files'>";
    echo "<p>Uploaded Files:</p>";
    echo "<ul>";
    echo "<li><a href='" . $file1Path . "'>" . $img1_name . "</a></li>";
    echo "<li><a href='" . $file2Path . "'>" . $img2_name . "</a></li>";
    echo "</ul>";
    echo "</div>";
}

function getImageDetails($filePath) {
    $details = [];
    list($width, $height) = getimagesize($filePath);
    $details['width'] = $width;
    $details['height'] = $height;

    // Assuming DPI extraction for JPEG images only
    if (exif_imagetype($filePath) == IMAGETYPE_JPEG) {
        $exif = exif_read_data($filePath);
        if (isset($exif['XResolution']) && isset($exif['YResolution'])) {
            $details['dpi'] = $exif['XResolution'] . 'x' . $exif['YResolution'];
        }
    }

    return $details;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Rulers</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .uploaded-files {
            margin-top: 20px;
        }
        
        .uploaded-files ul {
            list-style: none;
            padding: 0;
        }
        
        .uploaded-files ul li {
            margin-bottom: 10px;
        }
        
        .image-preview {
            position: relative;
            display: inline-block;
            margin: 20px;
        }
        
        .ruler-label {
            position: absolute;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 2px 5px;
            border: 1px solid #ccc;
            font-size: 12px;
            color: #000;
        }
        
        .horizontal-label {
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
        }
        
        .vertical-label {
            top: 50%;
            left: -60px;
            transform: translateY(-50%);
        }
        
        canvas {
            position: absolute;
            top: 0;
            left: 0;
        }
    </style>
</head>

<body>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Image Rulers</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item">art work </li>
                    <li class="breadcrumb-item active">Image Rulers</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Upload Images</h5>
                            <!-- Upload Form -->
                            <form method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="file1" class="form-label">Select first image</label>
                                    <input class="form-control" type="file" name="file1" id="file1" required>
                                </div>
                                <div class="mb-3">
                                    <label for="file2" class="form-label">Select second image</label>
                                    <input class="form-control" type="file" name="file2" id="file2" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Upload</button>
                            </form>

                            <!-- Display Uploaded Images -->
                            <?php
                            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                echo "<div class='results'>";
                                $details1 = getImageDetails($file1Path);
                                $details2 = getImageDetails($file2Path);
                                echo "<h2>Image 1 Details:</h2>";
                                echo "<p>Width: " . $details1['width'] . " pixels</p>";
                                echo "<p>Height: " . $details1['height'] . " pixels</p>";
                                if (isset($details1['dpi'])) {
                                    echo "<p>DPI: " . $details1['dpi'] . "</p>";
                                }
                                echo "<h2>Image 2 Details:</h2>";
                                echo "<p>Width: " . $details2['width'] . " pixels</p>";
                                echo "<p>Height: " . $details2['height'] . " pixels</p>";
                                if (isset($details2['dpi'])) {
                                    echo "<p>DPI: " . $details2['dpi'] . "</p>";
                                }

                                echo "<div class='image-preview' id='preview1'>";
                                echo "<img src='$file1Path' alt='Image 1' id='image1'>";
                                echo "<canvas id='canvas1'></canvas>";
                                echo "<div class='ruler-label horizontal-label' id='label1'></div>";
                                echo "<div class='ruler-label vertical-label' id='label2'></div>";
                                echo "</div>";

                                echo "<div class='image-preview' id='preview2'>";
                                echo "<img src='$file2Path' alt='Image 2' id='image2'>";
                                echo "<canvas id='canvas2'></canvas>";
                                echo "<div class='ruler-label horizontal-label' id='label3'></div>";
                                echo "<div class='ruler-label vertical-label' id='label4'></div>";
                                echo "</div>";
                                echo "</div>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->

    

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/chart.js/chart.umd.js"></script>
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.min.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            function drawRulers(imageId, canvasId, labelIdX, labelIdY) {
                const img = document.getElementById(imageId);
                const canvas = document.getElementById(canvasId);
                const ctx = canvas.getContext('2d');
                const labelX = document.getElementById(labelIdX);
                const labelY = document.getElementById(labelIdY);
                img.onload = function() {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);
                    
                    // Draw rulers
                    ctx.strokeStyle = "#000";
                    ctx.lineWidth = 1;
                    
                    // Horizontal ruler
                    for (let i = 0; i <= img.width; i += 50) {
                        ctx.beginPath();
                        ctx.moveTo(i, 0);
                        ctx.lineTo(i, 10);
                        ctx.stroke();
                        ctx.fillText(i, i, 20);
                    }
                    
                    // Vertical ruler
                    for (let i = 0; i <= img.height; i += 50) {
                        ctx.beginPath();
                        ctx.moveTo(0, i);
                        ctx.lineTo(10, i);
                        ctx.stroke();
                        ctx.fillText(i, 20, i);
                    }
                    
                    // Set labels
                    labelX.textContent = `Width: ${img.width}px`;
                    labelY.textContent = `Height: ${img.height}px`;
                }
            }
            
            drawRulers('image1', 'canvas1', 'label1', 'label2');
            drawRulers('image2', 'canvas2', 'label3', 'label4');
        });
    </script>

</body>

</html>
