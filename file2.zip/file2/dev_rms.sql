-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2024 at 06:33 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dev_rms`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_data`
--

CREATE TABLE `activity_data` (
  `levelzero` varchar(10) NOT NULL,
  `levelone` varchar(100) NOT NULL,
  `leveltwo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `activity_level`
--

CREATE TABLE `activity_level` (
  `levels` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity_level`
--

INSERT INTO `activity_level` (`levels`) VALUES
('zero'),
('one'),
('two');

-- --------------------------------------------------------

--
-- Table structure for table `document_transaction`
--

CREATE TABLE `document_transaction` (
  `document_oid` int(11) NOT NULL,
  `ticket_oid` int(11) NOT NULL,
  `file_name` varchar(500) NOT NULL,
  `data` varchar(500) NOT NULL,
  `path` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `enum_setting`
--

CREATE TABLE `enum_setting` (
  `oid` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `label` varchar(1000) NOT NULL,
  `value` varchar(1000) NOT NULL,
  `value2` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `form_mapping`
--

CREATE TABLE `form_mapping` (
  `oid` int(11) NOT NULL,
  `country_oid` int(11) NOT NULL,
  `activity_oid` int(11) NOT NULL,
  `activity_type_oid` int(11) NOT NULL,
  `form_oid` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL,
  `upload_oid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `form_transaction`
--

CREATE TABLE `form_transaction` (
  `oid` int(11) NOT NULL,
  `form_oid` varchar(200) NOT NULL,
  `field_1` varchar(200) NOT NULL,
  `field_2` varchar(200) NOT NULL,
  `field_3` varchar(200) NOT NULL,
  `field_4` varchar(200) NOT NULL,
  `field_5` varchar(200) NOT NULL,
  `field_6` varchar(200) NOT NULL,
  `field_7` varchar(200) NOT NULL,
  `field_8` varchar(200) NOT NULL,
  `field_9` varchar(200) NOT NULL,
  `field_10` varchar(200) NOT NULL,
  `field_11` varchar(200) NOT NULL,
  `field_12` varchar(200) NOT NULL,
  `field_13` varchar(200) NOT NULL,
  `field_14` varchar(200) NOT NULL,
  `field_15` varchar(200) NOT NULL,
  `field_16` varchar(200) NOT NULL,
  `field_17` varchar(200) NOT NULL,
  `field_18` varchar(200) NOT NULL,
  `field_19` varchar(200) NOT NULL,
  `field_20` varchar(200) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `img_id` int(50) NOT NULL,
  `img1` varchar(50) NOT NULL,
  `img2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`img_id`, `img1`, `img2`) VALUES
(1, 'img1-1', 'img2-1'),
(2, 'img1-2', 'img2-2'),
(3, 'img1-3', 'img2-3'),
(4, 'img1-4', 'img2-4'),
(5, 'img1-5', 'img2-5'),
(6, 'img1-6', 'img2-6'),
(7, 'img1-7', 'img2-7'),
(8, 'img1-8', 'img2-8'),
(9, 'img1-9', 'img2-9'),
(10, 'img1-10', 'img2-10'),
(11, 'img1-11', 'img2-11'),
(12, 'img1-12', 'img2-12'),
(13, 'img1-13', 'img2-13'),
(14, 'img1-14', 'img2-14'),
(15, 'img1-15', 'img2-15'),
(16, 'img1-16', 'img2-16'),
(17, 'img1-17', 'img2-17'),
(18, 'img1-18', 'img2-18'),
(19, 'img1-19', 'img2-19'),
(20, 'img1-20', 'img2-20'),
(21, 'img1-21', 'img2-21'),
(22, 'img1-22', 'img2-22'),
(23, 'img1-23', 'img2-23'),
(24, 'img1-24', 'img2-24'),
(25, 'img1-25', 'img2-25'),
(26, 'img1-26', 'img2-26'),
(27, 'img1-27', 'img2-27'),
(28, 'img1-28', 'img2-28'),
(29, 'img1-29', 'img2-29'),
(30, 'img1-30', 'img2-30'),
(31, 'img1-31', 'img2-31'),
(32, 'img1-32', 'img2-32'),
(33, 'img1-33', 'img2-33'),
(34, 'img1-34', 'img2-34'),
(35, 'img1-35', 'img2-35'),
(36, 'img1-36', 'img2-36'),
(37, 'img1-37', 'img2-37'),
(38, 'img1-38', 'img2-38'),
(39, 'img1-39', 'img2-39'),
(40, 'img1-40', 'img2-40'),
(41, 'img1-41', 'img2-41'),
(42, 'img1-42', 'img2-42'),
(43, 'img1-43', 'img2-43'),
(44, 'img1-44', 'img2-44'),
(45, 'img1-45', 'img2-45'),
(46, 'img1-46', 'img2-46'),
(47, 'img1-47', 'img2-47'),
(48, 'img1-48', 'img2-48'),
(49, 'img1-49', 'img2-49'),
(50, 'img1-50', 'img2-50'),
(51, 'img1-51', 'img2-51'),
(52, 'img1-52', 'img2-52'),
(53, 'img1-53', 'img2-53'),
(54, 'img1-54', 'img2-54'),
(55, 'img1-55', 'img2-55'),
(56, 'img1-56', 'img2-56'),
(57, 'img1-57', 'img2-57'),
(58, 'img1-58', 'img2-58'),
(59, 'img1-59', 'img2-59'),
(60, 'img1-60', 'img2-60'),
(61, 'img1-61', 'img2-61'),
(62, 'img1-62', 'img2-62'),
(63, 'img1-63', 'img2-63'),
(64, 'img1-64', 'img2-64'),
(65, 'img1-65', 'img2-65'),
(66, 'img1-66', 'img2-66'),
(67, 'img1-67', 'img2-67'),
(68, 'img1-68', 'img2-68'),
(69, 'img1-69', 'img2-69'),
(70, 'img1-70', 'img2-70'),
(71, 'img1-71', 'img2-71'),
(72, 'img1-72', 'img2-72'),
(73, 'img1-73', 'img2-73'),
(74, 'img1-74', 'img2-74'),
(75, 'img1-75', 'img2-75'),
(76, 'img1-76', 'img2-76'),
(77, 'img1-77', 'img2-77'),
(78, 'img1-78', 'img2-78'),
(79, 'img1-79', 'img2-79'),
(80, 'img1-80', 'img2-80'),
(81, 'img1-81', 'img2-81'),
(82, 'img1-82', 'img2-82'),
(83, 'img1-83', 'img2-83'),
(84, 'img1-84', 'img2-84'),
(85, 'img1-85', 'img2-85'),
(86, 'img1-86', 'img2-86'),
(87, 'img1-87', 'img2-87'),
(88, 'img1-88', 'img2-88'),
(89, 'img1-89', 'img2-89'),
(90, 'img1-90', 'img2-90'),
(91, 'img1-91', 'img2-91'),
(92, 'img1-92', 'img2-92'),
(93, 'img1-93', 'img2-93'),
(94, 'img1-94', 'img2-94'),
(95, 'img1-95', 'img2-95'),
(96, 'img1-96', 'img2-96'),
(97, 'img1-97', 'img2-97'),
(98, 'img1-98', 'img2-98'),
(99, 'img1-99', 'img2-99'),
(100, 'img1-100', 'img2-100'),
(101, 'img1-101', 'img2-101'),
(102, 'img1-102', 'img2-102'),
(103, 'img1-103', 'img2-103'),
(104, 'img1-104', 'img2-104'),
(105, 'img1-105', 'img2-105'),
(106, 'img1-106', 'img2-106'),
(107, 'img1-107', 'img2-107'),
(108, 'img1-108', 'img2-108'),
(109, 'img1-109', 'img2-109'),
(110, 'img1-110', 'img2-110'),
(111, 'img1-111', 'img2-111'),
(112, 'img1-112', 'img2-112'),
(113, 'img1-113', 'img2-113'),
(114, 'img1-114', 'img2-114'),
(115, 'img1-115', 'img2-115'),
(116, 'img1-116', 'img2-116'),
(117, 'img1-117', 'img2-117'),
(118, 'img1-118', 'img2-118'),
(119, 'img1-119', 'img2-119'),
(120, 'img1-120', 'img2-120'),
(121, 'img1-121', 'img2-121'),
(122, 'img1-122', 'img2-122'),
(123, 'img1-123', 'img2-123'),
(124, 'img1-124', 'img2-124'),
(125, 'img1-125', 'img2-125'),
(126, 'img1-126', 'img2-126'),
(127, 'img1-127', 'img2-127'),
(128, 'img1-128', 'img2-128'),
(129, 'img1-129', 'img2-129'),
(130, 'img1-130', 'img2-130'),
(131, 'img1-131', 'img2-131'),
(132, 'img1-132', 'img2-132'),
(133, 'img1-133', 'img2-133'),
(134, 'img1-134', 'img2-134'),
(135, 'img1-135', 'img2-135'),
(136, 'img1-136', 'img2-136'),
(137, 'img1-137', 'img2-137'),
(138, 'img1-138', 'img2-138'),
(139, 'img1-139', 'img2-139'),
(140, 'img1-140', 'img2-140'),
(141, 'img1-141', 'img2-141'),
(142, 'img1-142', 'img2-142'),
(143, 'img1-143', 'img2-143'),
(144, 'img1-144', 'img2-144'),
(145, 'img1-145', 'img2-145'),
(146, 'img1-146', 'img2-146'),
(147, 'img1-147', 'img2-147'),
(148, 'img1-148', 'img2-148'),
(149, 'img1-149', 'img2-149'),
(150, 'img1-150', 'img2-150'),
(151, 'img1-151', 'img2-151'),
(152, 'img1-152', 'img2-152'),
(153, 'img1-153', 'img2-153'),
(154, 'img1-154', 'img2-154'),
(155, 'img1-155', 'img2-155'),
(156, 'img1-156', 'img2-156'),
(157, 'img1-157', 'img2-157'),
(158, 'img1-158', 'img2-158'),
(159, 'img1-159', 'img2-159'),
(160, 'img1-160', 'img2-160'),
(161, 'img1-161', 'img2-161'),
(162, 'img1-162', 'img2-162'),
(163, 'img1-163', 'img2-163'),
(164, 'img1-164', 'img2-164'),
(165, 'img1-165', 'img2-165'),
(166, 'img1-166', 'img2-166'),
(167, 'img1-167', 'img2-167'),
(168, 'img1-168', 'img2-168'),
(169, 'img1-169', 'img2-169'),
(170, 'img1-170', 'img2-170'),
(171, 'img1-171', 'img2-171'),
(172, 'img1-172', 'img2-172'),
(173, 'img1-173', 'img2-173'),
(174, 'img1-174', 'img2-174'),
(175, 'img1-175', 'img2-175'),
(176, 'img1-176', 'img2-176'),
(177, 'img1-177', 'img2-177'),
(178, 'img1-178', 'img2-178'),
(179, 'img1-179', 'img2-179'),
(180, 'img1-180', 'img2-180'),
(181, 'img1-181', 'img2-181'),
(182, 'img1-182', 'img2-182'),
(183, 'img1-183', 'img2-183'),
(184, 'img1-184', 'img2-184'),
(185, 'img1-185', 'img2-185'),
(186, 'img1-186', 'img2-186'),
(187, 'img1-187', 'img2-187'),
(188, 'img1-188', 'img2-188'),
(189, 'img1-189', 'img2-189'),
(190, 'img1-190', 'img2-190'),
(191, 'img1-191', 'img2-191'),
(192, 'img1-192', 'img2-192'),
(193, 'img1-193', 'img2-193'),
(194, 'img1-194', 'img2-194'),
(195, 'img1-195', 'img2-195'),
(196, 'img1-196', 'img2-196'),
(197, 'img1-197', 'img2-197'),
(198, 'img1-198', 'img2-198'),
(199, 'img1-199', 'img2-199'),
(200, 'img1-200', 'img2-200'),
(201, 'img1-201', 'img2-201'),
(202, 'img1-202', 'img2-202'),
(203, 'img1-203', 'img2-203'),
(204, 'img1-204', 'img2-204'),
(205, 'img1-205', 'img2-205'),
(206, 'img1-206', 'img2-206'),
(207, 'img1-207', 'img2-207'),
(208, 'img1-208', 'img2-208'),
(209, 'img1-209', 'img2-209'),
(210, 'img1-210', 'img2-210'),
(211, 'img1-211', 'img2-211'),
(212, 'img1-212', 'img2-212'),
(213, 'img1-213', 'img2-213'),
(214, 'img1-214', 'img2-214'),
(215, 'img1-215', 'img2-215'),
(216, 'img1-216', 'img2-216'),
(217, 'img1-217', 'img2-217'),
(218, 'img1-218', 'img2-218'),
(219, 'img1-219', 'img2-219'),
(220, 'img1-220', 'img2-220'),
(221, 'img1-221', 'img2-221'),
(222, 'img1-222', 'img2-222'),
(223, 'img1-223', 'img2-223'),
(224, 'img1-224', 'img2-224'),
(225, 'img1-225', 'img2-225'),
(226, 'img1-226', 'img2-226'),
(227, 'img1-227', 'img2-227'),
(228, 'img1-228', 'img2-228'),
(229, 'img1-229', 'img2-229'),
(230, 'img1-230', 'img2-230'),
(231, 'img1-231', 'img2-231'),
(232, 'img1-232', 'img2-232'),
(233, 'img1-233', 'img2-233'),
(234, 'img1-234', 'img2-234'),
(235, 'img1-235', 'img2-235'),
(236, 'img1-236', 'img2-236'),
(237, 'img1-237', 'img2-237'),
(238, 'img1-238', 'img2-238'),
(239, 'img1-239', 'img2-239'),
(240, 'img1-240', 'img2-240'),
(241, 'img1-241', 'img2-241'),
(242, 'img1-242', 'img2-242'),
(243, 'img1-243', 'img2-243'),
(244, 'img1-244', 'img2-244'),
(245, 'img1-245', 'img2-245'),
(246, 'img1-246', 'img2-246'),
(247, 'img1-247', 'img2-247'),
(248, 'img1-248', 'img2-248'),
(249, 'img1-249', 'img2-249'),
(250, 'img1-250', 'img2-250'),
(251, 'img1-251', 'img2-251'),
(252, 'img1-252', 'img2-252'),
(253, 'img1-253', 'img2-253');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Sno` int(11) NOT NULL,
  `Level` varchar(255) NOT NULL,
  `Parent` varchar(255) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Sno`, `Level`, `Parent`, `Description`) VALUES
(1, 'dfasdf8', 'qwefw', 'dsfsdfa');

-- --------------------------------------------------------

--
-- Table structure for table `master_activity`
--

CREATE TABLE `master_activity` (
  `oid` int(11) NOT NULL,
  `level` varchar(100) NOT NULL,
  `parent_oid` varchar(100) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `label` varchar(1000) NOT NULL,
  `levelone` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `master_activity`
--

INSERT INTO `master_activity` (`oid`, `level`, `parent_oid`, `description`, `label`, `levelone`, `status`, `creation_user`, `last_modification_user`, `creation_time`, `last_modification_time`) VALUES
(30, 'zero', 'base-level', 'artwork', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 'one', 'artwork', 'east', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 'two', 'west', 'comparison of PDF', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 'one', 'ASM', 'west', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 'one', 'SE', 'east', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 'two', 'artwork', 'compare', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 'zero', 'base-level', 'fnf ', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 'one', 'artwork', 'esat', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 'two', 'east', 'se -not sales', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 'zero', 'base-level', 'mca', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 'zero', 'base-level', 'artwork', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 'one', 'artwork', 'west', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 'two', 'North', 'ASM', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, 'two', 'South', 'pdf compare', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, 'zero', 'base-level', 'artwork', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, 'one', 'artwork', 'west', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, 'two', 'west', 'image comparison', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, 'zero', 'base-level', 'artwork', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 'one', 'artwork', 'west', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 'two', 'west', 'text compariosn', '', '', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `master_auto_config`
--

CREATE TABLE `master_auto_config` (
  `oid` int(11) NOT NULL,
  `activity_oid` int(11) NOT NULL,
  `activity_type_oid` int(11) NOT NULL,
  `activity_value_oid` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL,
  `approver_flag` int(11) NOT NULL,
  `approver_flag1` int(11) NOT NULL,
  `approver_flag2` int(11) NOT NULL,
  `approver_flag3` int(11) NOT NULL,
  `approver_flag4` int(11) NOT NULL,
  `approver_flag5` int(11) NOT NULL,
  `approver_flag6` int(11) NOT NULL,
  `multiple_flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `master_form`
--

CREATE TABLE `master_form` (
  `oid` int(11) NOT NULL,
  `form_name` varchar(400) NOT NULL,
  `table_oid` int(11) NOT NULL,
  `form_type` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL,
  `upload_oid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `master_form_fields`
--

CREATE TABLE `master_form_fields` (
  `oid` int(11) NOT NULL,
  `form_oid` int(11) NOT NULL,
  `field_name` varchar(400) NOT NULL,
  `field_description` varchar(2000) NOT NULL,
  `field_label` varchar(2000) NOT NULL,
  `field_header` varchar(2000) NOT NULL,
  `datatype` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `page_master`
--

CREATE TABLE `page_master` (
  `page_oid` int(11) NOT NULL,
  `parent_oid` int(11) NOT NULL,
  `sort_oid` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title1` varchar(100) NOT NULL,
  `title2` varchar(100) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pdf_master`
--

CREATE TABLE `pdf_master` (
  `pdf_id` int(11) NOT NULL,
  `pdf1` varchar(100) NOT NULL,
  `pdf2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pdf_master`
--

INSERT INTO `pdf_master` (`pdf_id`, `pdf1`, `pdf2`) VALUES
(1, 'uploads/pdf1-1719552429.pdf', 'uploads/pdf2-1719552429.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `soa_data`
--

CREATE TABLE `soa_data` (
  `soa_oid` int(11) NOT NULL,
  `user_oid` int(11) NOT NULL,
  `activity_oid` int(11) NOT NULL,
  `activity_type_oid` int(11) NOT NULL,
  `activity_value_oid` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_madification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_activity`
--

CREATE TABLE `ticket_activity` (
  `oid` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `ticket_oid` int(11) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  `total_duration` varchar(500) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL,
  `reason` varchar(1000) NOT NULL,
  `user_group_oid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket_activity`
--

INSERT INTO `ticket_activity` (`oid`, `type`, `ticket_oid`, `description`, `status`, `total_duration`, `creation_user`, `last_modification_user`, `creation_time`, `last_modification_time`, `reason`, `user_group_oid`) VALUES
(1, 0, 100, 'mouse', 0, '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'not working', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_comment`
--

CREATE TABLE `ticket_comment` (
  `oid` int(11) NOT NULL,
  `ticket_oid` int(11) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_transaction`
--

CREATE TABLE `ticket_transaction` (
  `ticket_oid` int(11) NOT NULL,
  `activity_oid` int(11) NOT NULL,
  `activity_type_oid` int(11) NOT NULL,
  `activity_value_oid` int(11) NOT NULL,
  `business_unit_oid` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_group_master`
--

CREATE TABLE `user_group_master` (
  `user_group_oid` int(11) NOT NULL,
  `user_group_name` varchar(50) NOT NULL,
  `creation_user` int(11) NOT NULL,
  `last_modification_user` int(11) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_group_master`
--

INSERT INTO `user_group_master` (`user_group_oid`, `user_group_name`, `creation_user`, `last_modification_user`, `creation_time`, `last_modification_time`) VALUES
(1, 'user', 123, 123, '2024-05-20 10:07:54', '2024-05-20 10:07:54'),
(2, 'approver1', 10, 10, '2024-05-20 10:12:18', '2024-05-20 10:12:18'),
(3, 'approver2', 10, 10, '2024-05-20 10:13:12', '2024-05-20 10:13:12'),
(4, 'super Admin', 10, 10, '2024-05-20 10:13:35', '2024-05-20 10:13:35'),
(6, 'head of department ', 10, 4, '2024-06-07 07:32:14', '2024-06-07 07:32:14'),
(7, 'approver2', 1, 2, '2024-06-11 17:43:53', '2024-06-11 17:43:53'),
(8, 'approver2', 1, 2, '2024-06-11 17:43:59', '2024-06-11 17:43:59');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `user_oid` int(11) NOT NULL,
  `user_group_oid` varchar(100) NOT NULL,
  `display_name` varchar(500) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `creation_time` datetime NOT NULL,
  `last_modification_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`user_oid`, `user_group_oid`, `display_name`, `email`, `password`, `creation_time`, `last_modification_time`) VALUES
(0, 'admin', 'vinay', NULL, '000', '2024-05-31 11:54:54', '2024-05-31 11:54:54'),
(0, 'emp', 'abhi', NULL, '0000', '2024-05-31 11:56:37', '2024-05-31 11:56:37'),
(0, 'emp', 'rajat', NULL, '111', '2024-05-31 11:58:09', '2024-05-31 11:58:09'),
(0, 'admin', 'abhi', NULL, '111', '2024-05-31 12:00:24', '2024-05-31 12:00:24'),
(0, 'admin', 'vinay', NULL, '000', '2024-06-15 11:59:26', '2024-06-15 11:59:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`Sno`);

--
-- Indexes for table `master_activity`
--
ALTER TABLE `master_activity`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `pdf_master`
--
ALTER TABLE `pdf_master`
  ADD PRIMARY KEY (`pdf_id`);

--
-- Indexes for table `user_group_master`
--
ALTER TABLE `user_group_master`
  ADD PRIMARY KEY (`user_group_oid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `img_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=254;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `Sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_activity`
--
ALTER TABLE `master_activity`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `pdf_master`
--
ALTER TABLE `pdf_master`
  MODIFY `pdf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_group_master`
--
ALTER TABLE `user_group_master`
  MODIFY `user_group_oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
