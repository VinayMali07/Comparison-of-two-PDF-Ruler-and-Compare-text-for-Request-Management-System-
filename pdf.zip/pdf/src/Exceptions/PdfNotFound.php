<?php

namespace Spatie\PdfToText\Exceptions;

use Exception;

class PdfNotFound extends Exception
{
}
